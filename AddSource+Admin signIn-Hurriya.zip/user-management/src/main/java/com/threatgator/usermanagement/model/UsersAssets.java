package com.threatgator.usermanagement.model;

public class UsersAssets {
    private String organizationType;
    private String location;
    private String OS_version;
}
